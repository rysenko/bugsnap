<!-- This Source Code Form is subject to the terms of the Mozilla Public
   - License, v. 2.0. If a copy of the MPL was not distributed with this
   - file, You can obtain one at http://mozilla.org/MPL/2.0/. -->

# Third-party APIs #

This section include modules you've added to the SDK. The tutorial on
[adding menu items to Firefox](dev-guide/tutorials/adding-menus.html)
explains how to add third-party modules to your SDK installation.

<ul id="module-index"></ul>
