<!-- This Source Code Form is subject to the terms of the Mozilla Public
   - License, v. 2.0. If a copy of the MPL was not distributed with this
   - file, You can obtain one at http://mozilla.org/MPL/2.0/. -->

<span class="aside">
For more information on testing in the Add-on SDK, see the
[Unit Testing](dev-guide/tutorials/unit-testing.html)
tutorial.
</span>

This module contains the package's main program, which does a
bit of high-level setup and then delegates test finding and running to
the `harness` module.
