

if (!window.btoa) window.btoa = $.base64.btoa
if (!window.atob) window.atob = $.base64.atob

var geminiUrl = "http://pxaltair/gemini/api/";
var geminiUsername = $.base64.btoa('manager:wzhhx2ratj'); // user:apikey

$(function() {
    $( "#issue" ).autocomplete({
      minLength: 0,
      source: function(request, response){
		var geminiData = {
						   SearchKeywords: request.term,
						   IncludeClosed: "false",
						   Projects: "ALL"
						 }

		$.ajax({
			url: geminiUrl + "items/filtered",
			type: "POST",
			data: geminiData,
			headers: { "Authorization": "Basic " + geminiUsername },
			success: function( data ) {
				response( $.map( data, function( item ) {
				  return item;
				}));
			}
		});
		},
      focus: function( event, ui ) {
        $( "#issue" ).val( ui.item.Title );
        return false;
      },
      select: function( event, ui ) {
        $( "#issue" ).val( ui.item.Title );
        $( "#issue" ).data("issue", ui.item );
        $( "#issue_id" ).text( ui.item.Id );
        $( "#issue_title" ).text( ui.item.Title );
        $( "#issue_priority" ).text( ui.item.Priority );
    
 
        return false;
      }
    });
	$("#submit").click( function (){
		var geminiData = {
			ProjectId: $( "#issue" ).data("issue").Project.Id,
			IssueId: $( "#issue" ).data("issue").Id,
			UserId: "1",
			Comment: $("#comment").val()
		};

		$.ajax({
		url: geminiUrl + "items/" + $( "#issue" ).data("issue").Id + "/comments",
		type: "POST",
		data: geminiData,
		headers: { "Authorization": "Basic " + geminiUsername },
		success: function( data ) {
			//alert('updated');
		}
		});
		
		geminiData.Name = "MyItems.txt";
		geminiData.Content = "some text";
		geminiData.ContentType = "text/plain";

		$.ajax({
		url: geminiUrl + "items/" + $( "#issue" ).data("issue").Id + "/attachments",
		type: "POST",
		data: geminiData,
		headers: { "Authorization": "Basic " + geminiUsername },
		success: function( data ) {
			alert('uploaded');
		}
		});
	});
    
  });




